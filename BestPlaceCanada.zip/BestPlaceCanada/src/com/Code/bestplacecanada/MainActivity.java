package com.Code.bestplacecanada;



import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.Code.bestplacecanada.library.JSONParser;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.ProgressDialog;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;



public class MainActivity extends Activity {
	TextView uid;
	TextView name1;
	TextView email1;
	Button Btngetdata;
	
	//URL to get JSON Array
	//Main URL
	static String mainurl="http://www.thephpcode.com/demo/test.php?dataset=";
	
	//Data Sets- "crime" --- "weather" -----"rent"
	static String dataset;
	
	//Actual URL
	private static String url;
	
	private static final String OBJ = "objects";
	
	//crime column
	private static final String YEAR = "year";
	private static final String GEO = "geo";
	private static final String Statistics = "statistics";
	private static final String Vector ="vector";
	private static final String Coordinate = "coordinate";
	private static final String Value="value";
	
	//Rent column
	private static final String Place = "place";
	private static final String Gc = "gc";
	private static final String Structure = "structure";
	private static final String Unit = "unit";
	
	//weather column
	private static final String temporature = "temporature";
	
	
	JSONArray jsobj = null;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
      
        setContentView(R.layout.activity_main);
        Btngetdata = (Button)findViewById(R.id.getdata);
        Btngetdata.setOnClickListener(new View.OnClickListener() {
		
        	
			@Override
			public void onClick(View view) {
				dataset="crime";//Based on the user input this value will change
				url = mainurl +dataset;
				//Log.d("Debug Siva", "onCreated called");
			
		         new JSONParse().execute();

				
			}
		});
        
        
    }


    
    private class JSONParse extends AsyncTask<String, String, JSONObject> {
    	 private ProgressDialog pDialog;
    	@Override
        protected void onPreExecute() {
            super.onPreExecute();
             uid = (TextView)findViewById(R.id.uid);
			 name1 = (TextView)findViewById(R.id.name);
			 email1 = (TextView)findViewById(R.id.email);
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Getting Data ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
            
    	}
    	
    	@Override
        protected JSONObject doInBackground(String... args) {
    		JSONParser jParser = new JSONParser();

    		// Getting JSON from URL
    		JSONObject json = jParser.getJSONFromUrl(url);
    		return json;
    	}
    	 @Override
         protected void onPostExecute(JSONObject json) {
    		 pDialog.dismiss();
    		
    		 try {
    			 Log.i("getJSONArray","Get Json Object");
    			 jsobj = json.getJSONArray(OBJ);
    	 			JSONObject c = jsobj.getJSONObject(0);
    				// Storing  JSON item in a Variable
    	 			
    				String id = c.getString(YEAR);
    				String name = c.getString(GEO);
    				String email = c.getString(Statistics); 
    				
    				//Importing TextView
    			//this is Sample display
    				final TextView uid = (TextView)findViewById(R.id.uid);
    				final TextView name1 = (TextView)findViewById(R.id.name);
    				final TextView email1 = (TextView)findViewById(R.id.email);
    				
    				//Set JSON Data in TextView
    				uid.setText(id);
    				name1.setText(name);
    				email1.setText(email);   

    				int len=jsobj.length();
    				for(int i=0;i<len;i++)
    				{
    					 c = jsobj.getJSONObject(i);
    					Log.i("DATA", c.getString(YEAR));
    					Log.i("DATA", c.getString(GEO));
    					Log.i("DATA", c.getString(Statistics));
    					Log.i("DATA", c.getString(Vector));
    					Log.i("DATA", c.getString(Coordinate));
    					Log.i("DATA", c.getString(Value));
    					
    				}
    				
    			
    		} catch (JSONException e) {
    			e.printStackTrace();
    		}

    		 
    	 }
    }
    
}
